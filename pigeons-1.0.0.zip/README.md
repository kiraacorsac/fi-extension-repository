# PIGEO'n'S - *P*rogram for *I*nteractive *G*rading and *E*valuation of *O*bjects a*n*d *S*cenes

![hello](imgs/hello.png)

Blender extenension to help with homework grading for course VV035 - 3D Modelling, taught at FI MUNI. Yes, we are proud of the name.

Developed by Dusan as part of semestral project, maintained by KiraaCorsac and other lectors of VV035.

Icons provided by the amazing Clair from @ccartstuff.

---

## Installation
TODO
## Use
TODO
## Development
You are very welcomed to contribute to development of PIGEO'n'S. We can roll out changes very quickly, so if you help us fix a bug early in the semester, it's likely that students enrolled in the same semester get to see the fix :)
